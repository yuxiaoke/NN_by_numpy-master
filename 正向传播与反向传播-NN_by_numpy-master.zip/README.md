1.介绍
======================
纯用numpy实现全连接网络的正向传播和反向传播，对mnist手写数字数据集进行训练和测试。

仅供学习交流~~~

2.环境安装
======================
pip install matplotlib

pip install numpy

3.训练与测试
======================
python nn.py

注
----------------------
可以用nn.py里面的check_grads方法验证我们的正向传播与反向传播是否正确

4.效果
======================
训练过程显示
----------------------
![训练过程显示](https://github.com/EK332/nn_by_numpy/blob/master/train.png)

损失
----------------------
![训练过程显示](https://github.com/EK332/nn_by_numpy/blob/master/loss.png)

准确率
----------------------
![训练过程显示](https://github.com/EK332/nn_by_numpy/blob/master/accuracy.png)

